-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2019 at 05:39 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project1`
--

-- --------------------------------------------------------

--
-- Table structure for table `danhmuc`
--

CREATE TABLE `danhmuc` (
  `id` int(20) NOT NULL,
  `name_danhmuc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `danhmuc`
--

INSERT INTO `danhmuc` (`id`, `name_danhmuc`) VALUES
(1, 'ASUS'),
(2, 'MSI'),
(3, 'DELL'),
(4, 'HP'),
(5, 'LENOVO');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(10) NOT NULL,
  `ten` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gia` int(25) NOT NULL,
  `hinh` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ngaynhap` date NOT NULL,
  `luotxem` int(100) NOT NULL,
  `name_danhmuc` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `mota` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`id`, `ten`, `gia`, `hinh`, `ngaynhap`, `luotxem`, `name_danhmuc`, `mota`) VALUES
(1, 'Laptop Asus UX333FA A4118T', 200, 'hinh.jpg', '2019-11-13', 111, 'ASUS\r\n\r\n\r\n\r\n', ''),
(2, 'Laptop Asus ZenBook UX333FA A4116T', 0, 'hinh2.jpg', '2019-11-14', 111, 'ASUS', ''),
(3, 'Laptop Asus ZenBook UX333FA A4117T', 0, 'hinh3.jpg', '2019-11-12', 111, 'ASUS', ''),
(4, 'Laptop Asus ZenBook UX333FN A4124T', 0, 'hinh5.jpg', '2019-11-15', 13, 'ASUS', ''),
(5, 'Laptop Asus ZenBook UX334FAC A4060T', 0, 'hinh7.jpg', '2019-11-15', 13, 'ASUS', ''),
(6, 'Laptop Asus ZenBook UX430UN GV097T', 0, 'hinh8.jpg', '2019-11-15', 13, 'ASUS', ''),
(7, 'Laptop Dell Inspiron 15 7591 (2019)', 100, 'maytinh7.jpg', '2019-11-06', 19, 'DELL', ''),
(8, 'Laptop Dell Inspiron G5 5590 N5590 (2019) 4F4Y41', 199, 'maytinh8.jpg', '2019-11-05', 20, 'DELL', ''),
(9, 'Laptop Dell Inspiron G5 5590 N5590 (2019) 4F4Y42', 199, 'maytinh9.jpg', '2019-11-08', 30, 'DELL', ''),
(10, 'Laptop Dell Inspiron G5 5590 N5590M (2019)', 220, 'maytinh10.jpg', '2019-11-04', 20, 'DELL', ''),
(11, 'Laptop Dell Inspiron G7 7590 N7590Z (2019)', 200, 'maytinh11.jpg', '0000-00-00', 20, 'DELL', ''),
(12, 'Laptop Gaming Dell G3 Inspiron 3590 N5I5517W', 300, 'maytinh12.jpg', '2019-11-09', 20, 'DELL', ''),
(13, 'Laptop Gaming MSI GE75 Raider 9SE 688VN', 300, 'maytinh13.jpg', '2019-11-26', 30, 'MSI', ''),
(14, 'Laptop Gaming MSI GL65 9SDK 054VN (per-key rgb)', 330, 'maytinh14.jpg', '2019-11-27', 40, 'MSI', ''),
(15, 'Laptop Gaming MSI GT76 Titan DT 9SG 097VN', 400, 'maytinh14.jpg', '2019-11-27', 40, 'MSI', ''),
(16, 'Laptop Gaming MSI Prestige 15 10SC 004VN', 300, 'maytinh16.jpg', '2019-11-28', 40, 'MSI', ''),
(17, 'Laptop Gaming MSI PS42 Modern 8RA 252VN', 300, 'maytinh17.jpg', '2019-11-29', 40, 'MSI', ''),
(18, 'Laptop Gaming MSI PS42 Modern 8RA 253VN', 300, 'maytinh18.jpg', '2019-11-28', 40, 'MSI', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `danhmuc`
--
ALTER TABLE `danhmuc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `danhmuc`
--
ALTER TABLE `danhmuc`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
