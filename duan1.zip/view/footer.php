<div class="footer bg-light">
      <div class="container">
        <div class="row">
          <div class="col-lg-3">
            <p class="mb-4"><img src="view/images/logo.png" alt="Image" class="img-fluid"></p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.</p>  
            <p><a href="#">Learn More</a></p>
          </div>
          <div class="col-lg-3">
            <h3 class="footer-heading"><span>Shop</span></h3>
            <ul class="list-unstyled">
                <li><a href="#">Thông tin</a></li>
                <li><a href="#">Sản phẩm mới</a></li>
                <li><a href="#">Sản phẩm bán chạy</a></li>
                
            </ul>
          </div>
          <div class="col-lg-3">
              <h3 class="footer-heading"><span>Dịch vụ</span></h3>
              <ul class="list-unstyled">
                  <li><a href="#">Bảo hành</a></li>
                  <li><a href="#">Sửa chữa</a></li>
                  <li><a href="#">Vệ sinh máy</a></li>
              </ul>
          </div>
          <div class="col-lg-3">
              <h3 class="footer-heading"><span>Liên hệ</span></h3>
              <ul class="list-unstyled">
                  <li><a href="#">Hổ trợ</a></li>
                  <li><a href="#">Cộng đồng</a></li>
                  
                  <li><a href="#">FAQ</a></li>
                  
              </ul>
          </div>
        </div>

        <div class="row">
          <div class="col-12">
            <div class="copyright">
                <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    

  </div>
  <!-- .site-wrap -->


  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15"/></svg></div>

  <script src="view/js/jquery-3.3.1.min.js"></script>
  <script src="view/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="view/js/jquery-ui.js"></script>
  <script src="view/js/popper.min.js"></script>
  <script src="view/js/bootstrap.min.js"></script>
  <script src="view/js/owl.carousel.min.js"></script>
  <script src="view/js/jquery.stellar.min.js"></script>
  <script src="view/js/jquery.countdown.min.js"></script>
  <script src="view/js/bootstrap-datepicker.min.js"></script>
  <script src="view/js/jquery.easing.1.3.js"></script>
  <script src="view/js/aos.js"></script>
  <script src="view/js/jquery.fancybox.min.js"></script>
  <script src="view/js/jquery.sticky.js"></script>
  <script src="view/js/jquery.mb.YTPlayer.min.js"></script>




  <script src="view/js/main.js"></script>

</body>

</html>