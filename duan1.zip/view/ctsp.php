


    <div class="intro-section site-blocks-cover innerpage" style="background-image: url('view/images/hero_1.jpg');">
      <div class="container">
        <div class="row align-items-center text-center border">
          <div class="col-lg-12 mt-5" data-aos="fade-up">
            <h1>Project Single Post</h1>
            <p class="text-white text-center">
              <a href="index.php">Home</a>
              <span class="mx-2">/</span>
              <span>Project Single</span>
            </p>
          </div>
        </div>
      </div>
    </div>


    
    
    <div class="site-section">
        <div class="container">
            <div class="row">
              <?php
            foreach ($dssphome as $showsp) 
          {
            echo '
                <div class="col-md-7 mb-4">
                    <img src="uploaded/'.$showsp['hinh'] .'" alt="Image" class="img-fluid">
                </div>
                <div class="col-md-4 ml-auto">
                    <h2 class="text-black mb-4">'.$showsp['ten'].'</h2>
                    <pclass="mb-5">'.$showsp['mota'].' </p>
                    <p class="mb-5">'.$showsp['gia'].'</p>
                    <p><a href="#" class="btn btn-primary rounded-0 py-3 px-5">Add to cart</a></p>
                </div>
            </div>
        </div>
    </div>';
  }
          ?>