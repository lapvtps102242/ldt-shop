<?php
// function loadcatalog(){
//     $sql="select * from danhmuc order by id desc";
//     $kq=pdo_query($sql);
//     return $kq; 
// }
function showsp(){
    $sql="select * from sanpham order by id desc";
    $sql= " limit 6";
    $kq=pdo_query($sql);
    return $kq;
}
// function loadblog(){
//     $sql="select * from blog order by id desc";
//     $kq=pdo_query($sql);
//     return $kq;
// }
function shownews_cata($idcatalog){
    $sql="select * from loai where 1 by id desc limit 4";
    if($idcatalog>0){
        $sql.=" AND id=".$idcatalog;
    }
    $sql.=" order by id desc ";
    $kq=pdo_query($sql);
    return $kq;
}
function loadproducts($idcat=0,$kyw=""){
    $sql = "SELECT * FROM sanpham WHERE 1 ";
    if($idcat>0) {
        $sql.= " AND id=".$idcat;    
    }
    if($kyw!="") {
        $sql.=" AND ten like '%".$kyw."%'";
    }
    $sql.= " ORDER BY id desc";
    $sql.= " limit 0,6";
    $kq = pdo_query($sql);
    return $kq;
}
?>