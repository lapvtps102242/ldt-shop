<?php
    function get_name_cat($id){
        $sql="select name from danhmuc where id=".$id;
        $kq=pdo_query_one($sql);
        return $kq;
    }
    function loadcatalog(){
        $sql="select * from danhmuc order by id desc";
        $kq=pdo_query($sql);
        return $kq;
    }
    function loadProductHome () {
        $sql = "select * from sanpham ORDER by id desc limit 0,8";
        $kq = pdo_query($sql);
        return $kq;
    }
    function loadctsp($idsp) {
        $sql = "SELECT * FROM sanpham WHERE 1 ";
        if($idsp>0) {
            $sql.= " AND id=".$idsp;    
        }
        $kq = pdo_query($sql);
        return $kq;
    }
?>